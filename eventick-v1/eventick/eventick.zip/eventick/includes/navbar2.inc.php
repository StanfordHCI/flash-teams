   
    <div class="navbar">
  <div class="navbar-inner">
    <ul class="nav">
      <li class="active"><a href="index.php">All Events</a></li>
      <li><a href="myevents.php">My Events</a></li>
      <li><a href="collaborators.php">Collaborators</a></li>
    	<li><a href="following.php">Following</a></li>
    </ul>
  </div>
</div>