<div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container-fluid">
          <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <a class="brand" href="index.php">Eventick</a>
          <div class="nav-collapse collapse">
            <p class="navbar-text pull-right">
             <a href="new_event.php"> + New Event</a> |
              Logged in as <a href="#" class="navbar-link">test</a> |
              <a href="myevents.php"> My Events</a>
            </p>
            <ul class="nav">
              <li class="active"><a href="index.php">Events</a></li>             
              <li><a href="#contact"></a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
 